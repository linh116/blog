"Minimalist" Skin
====================

A port of the default CKEditor skin, Moono, without the gradients.

Jeff Lyon
[Albatross Digital](albatrossdigital.com)
