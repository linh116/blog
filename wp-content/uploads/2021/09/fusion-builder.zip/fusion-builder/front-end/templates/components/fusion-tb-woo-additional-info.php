<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 3.2
 */

?>
<script type="text/html" id="tmpl-fusion_tb_woo_additional_info-shortcode">
	{{{styles}}}
	<div {{{ _.fusionGetAttributes( wrapperAttr ) }}}>
		{{{output}}}
	</div>
</script>
